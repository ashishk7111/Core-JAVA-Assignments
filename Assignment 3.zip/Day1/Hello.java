
/*01.Write a program to print Hello World. Compile and run it using command prompt*/

class Hello {
 public static void main(String args[])
{
System.out.println("Hello World");
}
}
