/*02.Write a program to declare a variable named rollNo of integer type. Assign it a value (let say 100) to it and print the following statement roll no = 100 .*/


class DeclareVariable{
     public static void main(String args[]){
     int r=100;
     System.out.println("roll no = " + r );
      }
}